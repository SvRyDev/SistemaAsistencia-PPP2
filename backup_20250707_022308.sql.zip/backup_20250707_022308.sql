-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: db_asistencia_estudiantes
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `asistencia_estudiante`
--

DROP TABLE IF EXISTS `asistencia_estudiante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asistencia_estudiante` (
  `asistencia_estudiante_id` int(11) NOT NULL AUTO_INCREMENT,
  `estudiante_id` int(11) NOT NULL,
  `dia_fecha_id` int(11) DEFAULT NULL,
  `hora_entrada` time DEFAULT NULL,
  `hora_salida` time DEFAULT NULL,
  `estado_asistencia_id` int(11) DEFAULT NULL,
  `observacion` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`asistencia_estudiante_id`),
  KEY `estudiante_id` (`estudiante_id`),
  KEY `dia_fecha_id` (`dia_fecha_id`),
  KEY `fk_asistencia_estudiante_estado` (`estado_asistencia_id`),
  CONSTRAINT `asistencia_estudiante_ibfk_1` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiante` (`estudiante_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `asistencia_estudiante_ibfk_2` FOREIGN KEY (`dia_fecha_id`) REFERENCES `dia_asistencia` (`dia_fecha_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_asistencia_estudiante_estado` FOREIGN KEY (`estado_asistencia_id`) REFERENCES `estados_asistencia` (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistencia_estudiante`
--

LOCK TABLES `asistencia_estudiante` WRITE;
/*!40000 ALTER TABLE `asistencia_estudiante` DISABLE KEYS */;
INSERT INTO `asistencia_estudiante` VALUES (1,1,1,'21:49:00',NULL,2,NULL);
/*!40000 ALTER TABLE `asistencia_estudiante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carnet_estudiante`
--

DROP TABLE IF EXISTS `carnet_estudiante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carnet_estudiante` (
  `carnet_id` int(11) NOT NULL AUTO_INCREMENT,
  `estudiante_id` int(11) NOT NULL,
  `foto_path` varchar(255) DEFAULT NULL,
  `codigo_barras_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`carnet_id`),
  UNIQUE KEY `estudiante_id` (`estudiante_id`),
  UNIQUE KEY `foto_path` (`foto_path`),
  UNIQUE KEY `codigo_barras_path` (`codigo_barras_path`),
  CONSTRAINT `carnet_estudiante_ibfk_1` FOREIGN KEY (`estudiante_id`) REFERENCES `estudiante` (`estudiante_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carnet_estudiante`
--

LOCK TABLES `carnet_estudiante` WRITE;
/*!40000 ALTER TABLE `carnet_estudiante` DISABLE KEYS */;
/*!40000 ALTER TABLE `carnet_estudiante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dia_asistencia`
--

DROP TABLE IF EXISTS `dia_asistencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dia_asistencia` (
  `dia_fecha_id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `nombre_dia` varchar(20) DEFAULT NULL,
  `hora_entrada` time DEFAULT NULL,
  `hora_salida` time DEFAULT NULL,
  `min_tolerancia` int(11) DEFAULT NULL,
  `total_asistidos` int(11) DEFAULT NULL,
  `total_justificados` int(11) DEFAULT NULL,
  `total_tardanza` int(11) DEFAULT NULL,
  PRIMARY KEY (`dia_fecha_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dia_asistencia`
--

LOCK TABLES `dia_asistencia` WRITE;
/*!40000 ALTER TABLE `dia_asistencia` DISABLE KEYS */;
INSERT INTO `dia_asistencia` VALUES (1,'2025-07-06','Sunday','07:30:00','13:00:00',10,NULL,NULL,NULL);
/*!40000 ALTER TABLE `dia_asistencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados_asistencia`
--

DROP TABLE IF EXISTS `estados_asistencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estados_asistencia` (
  `id_estado` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_estado` varchar(20) NOT NULL,
  `abreviatura` varchar(5) NOT NULL,
  `color_hex` varchar(7) NOT NULL,
  `clase_boostrap` varchar(100) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_estado`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados_asistencia`
--

LOCK TABLES `estados_asistencia` WRITE;
/*!40000 ALTER TABLE `estados_asistencia` DISABLE KEYS */;
INSERT INTO `estados_asistencia` VALUES (1,'Presente','P','#28a745','success','fas fa-check'),(2,'Tarde','T','#ffc107','info','fas fa-clock'),(3,'Falta','F','#dc3545','danger','fas fa-times'),(4,'Justificado','J','#17a2b8','warning','fas fa-comment');
/*!40000 ALTER TABLE `estados_asistencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estudiante`
--

DROP TABLE IF EXISTS `estudiante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estudiante` (
  `estudiante_id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(11) DEFAULT NULL,
  `nombres` varchar(105) DEFAULT NULL,
  `apellidos` varchar(255) DEFAULT NULL,
  `dni` char(8) DEFAULT NULL,
  `grado_id` int(11) DEFAULT NULL,
  `seccion_id` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_update` datetime DEFAULT NULL,
  PRIMARY KEY (`estudiante_id`),
  KEY `fk_estudiante_grado` (`grado_id`),
  KEY `fk_estudiante_seccion` (`seccion_id`),
  CONSTRAINT `fk_estudiante_grado` FOREIGN KEY (`grado_id`) REFERENCES `grados` (`id_grado`),
  CONSTRAINT `fk_estudiante_seccion` FOREIGN KEY (`seccion_id`) REFERENCES `secciones` (`id_seccion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estudiante`
--

LOCK TABLES `estudiante` WRITE;
/*!40000 ALTER TABLE `estudiante` DISABLE KEYS */;
INSERT INTO `estudiante` VALUES (1,'STU-25-0001','ARTURO','SARAVIA REYES','70087799',1,1,'2025-07-06 19:30:43','2025-07-07 01:34:39'),(2,'STU-25-0002','DWFG','DWFG','62524362',3,2,'2025-07-06 19:30:43',NULL),(3,'STU-25-0003','GERGERG','DWFEG  E','12345678',2,4,'2025-07-06 19:30:43','2025-07-07 00:39:52'),(4,'STU-25-0004','MARÍA','GONZÁLEZ DÍAZ','11223344',1,1,'2025-07-06 19:30:43','2025-07-06 22:37:44');
/*!40000 ALTER TABLE `estudiante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grados`
--

DROP TABLE IF EXISTS `grados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grados` (
  `id_grado` int(11) NOT NULL AUTO_INCREMENT,
  `orden_num` varchar(5) NOT NULL,
  `nombre_completo` varchar(20) NOT NULL,
  PRIMARY KEY (`id_grado`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grados`
--

LOCK TABLES `grados` WRITE;
/*!40000 ALTER TABLE `grados` DISABLE KEYS */;
INSERT INTO `grados` VALUES (1,'1°','PRIMERO'),(2,'2°','SEGUNDO'),(3,'3°','TERCERO'),(4,'4°','CUARTO'),(5,'5°','QUINTO');
/*!40000 ALTER TABLE `grados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `secciones`
--

DROP TABLE IF EXISTS `secciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secciones` (
  `id_seccion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_seccion` varchar(10) NOT NULL,
  PRIMARY KEY (`id_seccion`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `secciones`
--

LOCK TABLES `secciones` WRITE;
/*!40000 ALTER TABLE `secciones` DISABLE KEYS */;
INSERT INTO `secciones` VALUES (1,'A'),(2,'B'),(3,'C'),(4,'D'),(5,'E');
/*!40000 ALTER TABLE `secciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_config`
--

DROP TABLE IF EXISTS `system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_config` (
  `id` int(11) NOT NULL,
  `name_school` varchar(100) NOT NULL,
  `academic_year` varchar(9) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `entry_time` time NOT NULL,
  `exit_time` time DEFAULT NULL,
  `time_tolerance` int(11) DEFAULT NULL,
  `time_zone` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_date_import` datetime DEFAULT NULL,
  `last_date_export` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_config`
--

LOCK TABLES `system_config` WRITE;
/*!40000 ALTER TABLE `system_config` DISABLE KEYS */;
INSERT INTO `system_config` VALUES (1,'Nombre del Colegio','2026','2026-02-07','2026-07-15','07:30:00','23:59:00',10,'America/Lima','2025-07-07 05:43:03','2025-07-05 23:27:26','2025-07-06 19:15:25');
/*!40000 ALTER TABLE `system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vista_estudiantes`
--

DROP TABLE IF EXISTS `vista_estudiantes`;
/*!50001 DROP VIEW IF EXISTS `vista_estudiantes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vista_estudiantes` AS SELECT
 1 AS `estudiante_id`,
  1 AS `codigo`,
  1 AS `nombres`,
  1 AS `apellidos`,
  1 AS `dni`,
  1 AS `id_grado`,
  1 AS `grado`,
  1 AS `grado_nombre`,
  1 AS `id_seccion`,
  1 AS `seccion`,
  1 AS `date_created` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_estudiantes`
--

/*!50001 DROP VIEW IF EXISTS `vista_estudiantes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_estudiantes` AS select `e`.`estudiante_id` AS `estudiante_id`,`e`.`codigo` AS `codigo`,`e`.`nombres` AS `nombres`,`e`.`apellidos` AS `apellidos`,`e`.`dni` AS `dni`,`g`.`id_grado` AS `id_grado`,`g`.`orden_num` AS `grado`,`g`.`nombre_completo` AS `grado_nombre`,`s`.`id_seccion` AS `id_seccion`,`s`.`nombre_seccion` AS `seccion`,`e`.`date_created` AS `date_created` from ((`estudiante` `e` left join `grados` `g` on(`e`.`grado_id` = `g`.`id_grado`)) left join `secciones` `s` on(`e`.`seccion_id` = `s`.`id_seccion`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-07  2:23:09
